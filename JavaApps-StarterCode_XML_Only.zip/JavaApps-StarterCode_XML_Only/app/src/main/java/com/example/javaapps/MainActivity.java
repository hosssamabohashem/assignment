/**
 * TODO : making the app inteactive
 *  add new commonet  - explain the package and import part and apply
 *     1-  understand the conection between the layour file and it;s java file
 *           - point to the onCreate metod
 *           - what is R
 *      2-  how to get value of any xml elemnt
 *          using findbyID
 *
 * -
 */

/** TODO ; TASKS
 *      1 -  create the diaplay method and test it from the order button
 *           - uss the textview doc ,  point to the set text (res id , and charcaters set)
 *           -  how to covnert int to string (dispaly quantity)
 *               - Integer.toString(int) ,  Convert using String.valueOf(int)
 *      2- start explaining  how to read from edittext
 *         -  understand resouce refence from java
 *         -  get the edit text name and set pass it isnetad of dummy name
 *         -  gettext() retunr Editable interface , so we need to convert it to string
 *         - handle the case whne the edit text is empty
 *      3- gettign the value of check box
 *         -  do it first using regular way
 *      4- spereate the code into subfinctions (getCustomerLocation  ,getCustomerPreference , getCustomerName)
 *      5- no need for quntiy fucntion , we need increment and decrement function
 *         - incrementMethod
 *            -  increas the qunity var by 1
 *            - we need method to only display quuntity
 *     6- explain the concepts of oop
 *        - and apply them here
 *     7- prevent user from increasing by showing him a toast message
 *        - creat toast message when do order
 *        - move it to sperate method and defien two fianls fo the message
 *
 */
package com.example.javaapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.javaapps.R;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {

    /**TODO
     *      1. get customer name
     *      2. get customer location
     *      3. get customer perfernce
     *      4. get quantity
     *         -  no more than 5
     *         -  no less than 1
     *      5- caulate the price
     *      6-  display thte order summry  in the summery view
     *      7- send it to the submit Order
     *      8-submit the order to your email
     */




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        getSupportActionBar().hide(); //<< this





    }





}
